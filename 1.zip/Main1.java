package oop;

import com.oop.Student1;
import com.oop.String;

public class Main1 {
	public static void main(String[] args) {
		Student1 c1= new Student1();
		c1.age=21;
		System.out.println(c1.age);
	}


}
