package oop;

import com.oop.Student2getterssetters;
import com.oop.String;

public class Main2getterssetters {
	public static void main(String[] args) {
		Student2getterssetters c2= new Student2getterssetters();
		c2.setage(21);
		System.out.println(c2.getage());
		
		
		c2.setname("tharani");
		System.out.println(c2.getname());
		
		
	}


}
