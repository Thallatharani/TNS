package oop;

import com.oop.Car3getterssetterAddfunctinality;
import com.oop.String;

public class Main3getterssetterAddfunctinality {
	public static void main(String[] args) {
		Student3getterssetterAddfunctinality Student = new Student3getterssetterAddfunctinality ();
		Student.setage (21);
		Student.setname ("tharani");
		Student.setidno ("3356");
		Student.setaddress ("ibrahimpatnam");
		//calling the function
		System.out.println (Student.run ());
	}

}
