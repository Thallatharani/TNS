package oop;

import com.oop.String;

public class Student1 {
	private String name;
	private String idno;
	private String address;
	public int age;
	


}
