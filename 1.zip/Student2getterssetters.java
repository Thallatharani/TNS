package oop;

import com.oop.String;

public class Student2getterssetters {
	private String name;
	private String idno;
	private String address;
	private int age;
	public int getage() {
		return age;
	}
	public void setage(int speed) {
		this.age = age;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getidno() {
		return idno;
	}
	public void setidno(String idno) {
		this.idno = idno;
	}
	public String getaddress() {
		return address;
	}
	public void setDrivers(String address) {
		this.address = address;
	}
	



}
