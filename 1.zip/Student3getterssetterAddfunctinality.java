package oop;

import com.oop.String;

public class Student3getterssetterAddfunctinality {
	private String name;
	private String idno;
	private String address;
	private int age;
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getidno() {
		return idno;
	}
	public void setidno(String idno) {
		this.idno = idno;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public int getage() {
		return age;
	}
	public void setage(int age) {
		this.age = age;
	}
	
	public String run() {
		if(name.equals("tharani") && idno.equals("3356")&& address.equals("ibrahimpatnam") 
				&& age >18) {
			return "Student is eligible for voting";
		}else {
			return "Student is not eligible for voting";
		}

}



}
