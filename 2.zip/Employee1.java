package oopEmployee;

public class Employee1 {
public Employee() {
		
		//Code block constructor general
	}

}
