package oopEmployee;

import com.oop.String;

public class Employee2getterssetters {
	private String empname;
	private String empid;
	private String empaddress;
	private int empage;
	public int getempage() {
		return empage;
	}
	public void setempage(int empage) {
		this.empage = empage;
	}
	public String getempname() {
		return empname;
	}
	public void setempid(String empname) {
		this.empname = empname;
	}
	public String getempid() {
		return empid;
	}
	public void setempid(String empid) {
		this.empid = empid;
	}
	public String getempaddress() {
		return empaddress;
	}
	public void setempaddress(String empaddress) {
		this.empaddress = empaddresss;
	}
	


}
