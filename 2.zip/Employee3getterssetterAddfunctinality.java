package oopEmployee;

import com.oop.String;

public class Employee3getterssetterAddfunctinality {
	private String empname;
	private String empid;
	private String empaddress;
	private int empage;
	
	public String getempname() {
		return empname;
	}
	public void setenpname(String eempname) {
		this.empname = empname;
	}
	public String getempid() {
		return empid;
	}
	public void setempid(String empid) {
		this.empid = empid;
	}
	public String getempaddress() {
		return empaddress;
	}
	public void setempaddress(String empaddress) {
		this.empaddress = empaddress;
	}
	public int getempage() {
		return empage;
	}
	public void setempage(int empage) {
		this.empage = empage;
	}
	
	public String run() {
		if(empname.equals("akash") && empid.equals("A2")&& empaddress.equals("bangloor") 
				&& empage >25) {
			return "Employee is working in office";
		}else {
			return "Employee is not working in office";
		}

}

}
