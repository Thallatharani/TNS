package oopEmployee;

import com.oop.Car1;
import com.oop.String;

public class Main1 {
	public static void main(String[] args) {
		Employee1 c1= new Employee1();
		c1.age=25;
		System.out.println(c1.empage);
	}


}
