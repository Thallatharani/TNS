package oopEmployee;

import oop.String;
import oop.Employee2getterssetters;

public class Main2getterssetters {
	public class Main2getterssetters {
		public static void main(String[] args) {
			Employee2getterssetters c2= new Employee2getterssetters();
			c2.setage(25);
			System.out.println(c2.getage());
			
			
			c2.setname("akash");
			System.out.println(c2.getname());
			
			
		}

}
