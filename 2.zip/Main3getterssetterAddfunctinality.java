package oopEmployee;

import oop.String;
import oop.Student3getterssetterAddfunctinality;

public class Main3getterssetterAddfunctinality {
	public class Main3getterssetterAddfunctinality {
		public static void main(String[] args) {
			Employee3getterssetterAddfunctinality Employee = new Employee3getterssetterAddfunctinality ();
			Student.setempage (25);
			Student.setname ("akash");
			Student.setidno ("A2");
			Student.setaddress ("bangloor");
			//calling the function
			System.out.println (Student.run ());
		}

}
